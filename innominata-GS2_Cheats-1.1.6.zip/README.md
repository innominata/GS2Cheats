﻿# Galactic Scale Cheats

Version 1.1.6 Updated for GS2 2.5.12. Some saves created on earlier versions cannot be loaded with GSCheats enabled. Uncheck it in settings, then load, reenable and save (as a different file, BACKUP YOUR SAVES)

This plugin adds a bunch of cheats to Galactic Scale 2.

Work in progress. Some options may not work quite right just yet.

Currently it contains the following:

- Multipliers for recipe Input/Output/Time Taken

- Unlimited Mecha Energy
- Fast Build
- Unlock Sail
- Unlock Warp
- Always Warp (Doesn't require warpers) (Thanks to code from Nebula)
- Boost Walk Speed
- Boost Sail Speed
- Boost Warp Speed

- Unlock All Research (Thanks to code from Windows10CE's DSPCheats mod.)
- Free Research (Thanks to code from Windows10CE's DSPCheats mod.)
- Research Speed Multiplier

- Always Craft (Doesn't require materials)
- Instant Craft

- Unlock Dyson Spheres (Thanks to code from Nebula)
- Start with Full Sphere (All lattitudes available)

Settings are configurable in the Galactic Scale Settings window. Entire mod can be enabled/disabled and settings
configured in game.

Some unlocks are irreversable without restarting (Ones that unlock research).

Join our discord https://discord.gg/NbpBn6gM6d for feature requests / bug reports

-innominata
